<?php

/*
 * This file is part of the Predis package.
 *
 * (c) 2009-2020 Daniele Alessandri
 * (c) 2021-2026 Till Krüss
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Predis\Command\Redis;

use Predis\Command\Command as RedisCommand;
use Predis\Command\Traits\Approx;
use Predis\Command\Traits\Keys;
use Predis\Command\Traits\Limit\Limit;

class SUNIONCARD extends RedisCommand
{
    use Keys {
        Keys::setArguments as setKeys;
    }
    use Approx {
        Approx::setArguments as setApprox;
    }
    use Limit {
        Limit::setArguments as setLimit;
    }

    protected static $keysArgumentPositionOffset = 0;
    protected static $approxArgumentPositionOffset = 1;
    protected static $limitArgumentPositionOffset = 2;

    public function getId()
    {
        return 'SUNIONCARD';
    }

    public function setArguments(array $arguments)
    {
        $this->setApprox($arguments);
        $arguments = $this->getArguments();

        $this->setLimit($arguments);
        $arguments = $this->getArguments();

        $this->setKeys($arguments);
        $this->filterArguments();
    }
}
